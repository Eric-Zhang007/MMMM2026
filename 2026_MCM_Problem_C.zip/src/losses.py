import torch
import torch.nn.functional as F
from typing import Dict


def get_prior_loss(model, config: Dict) -> torch.Tensor:
    """
    Explicit priors / regularizers.

    - L2 on theta/u: lambda_theta * mean(theta^2) + lambda_u * mean(u^2)
    - If time drift exists:
        * also bound drift scale with same lambda
        * random-walk smoothness: lambda_theta_rw * mean((rw_t - rw_{t-1})^2)
    - phi regularization: l1/l2/elasticnet with lambda_phi_l1/l2
    - beta center prior
    """
    mcfg = config.get("model", {})

    lambda_theta = float(mcfg.get("lambda_theta", 0.01))
    lambda_u = float(mcfg.get("lambda_u", 0.01))

    l_theta = lambda_theta * (model.theta.weight.pow(2).mean())
    l_u = lambda_u * (model.u.weight.pow(2).mean())

    lambda_theta_rw = float(mcfg.get("lambda_theta_rw", 0.0))
    lambda_u_rw = float(mcfg.get("lambda_u_rw", 0.0))

    if getattr(model, "use_time_drift", False) and (getattr(model, "theta_rw", None) is not None):
        l_theta = l_theta + lambda_theta * model.theta_rw.weight.pow(2).mean()
        if lambda_theta_rw > 0.0:
            W = model.theta_rw.weight.view(-1, model.max_week_cap)
            diff = W[:, 1:] - W[:, :-1]
            l_theta = l_theta + lambda_theta_rw * diff.pow(2).mean()

    if getattr(model, "use_time_drift", False) and (getattr(model, "u_rw", None) is not None):
        l_u = l_u + lambda_u * model.u_rw.weight.pow(2).mean()
        if lambda_u_rw > 0.0:
            W = model.u_rw.weight.view(-1, model.max_week_cap)
            diff = W[:, 1:] - W[:, :-1]
            l_u = l_u + lambda_u_rw * diff.pow(2).mean()

    phi_reg = str(mcfg.get("phi_reg", "none")).lower()
    lam_phi_l1 = float(mcfg.get("lambda_phi_l1", 0.0))
    lam_phi_l2 = float(mcfg.get("lambda_phi_l2", 0.0))

    w = model.phi.weight
    if phi_reg == "l1":
        l_phi = lam_phi_l1 * torch.norm(w, 1)
    elif phi_reg == "l2":
        l_phi = lam_phi_l2 * torch.norm(w, 2).pow(2)
    elif phi_reg == "elasticnet":
        l_phi = lam_phi_l1 * torch.norm(w, 1) + lam_phi_l2 * torch.norm(w, 2).pow(2)
    else:
        l_phi = torch.tensor(0.0, device=w.device)

    lambda_beta = float(mcfg.get("lambda_beta", 0.0))
    beta_center = float(mcfg.get("beta_center", 1.0))
    l_beta = lambda_beta * torch.sum((model.beta - beta_center).pow(2))

    return l_theta + l_u + l_phi + l_beta


def compute_loss(week_data: Dict, p_fan: torch.Tensor, s_total: torch.Tensor, config: Dict):
    """
    Pairwise hinge loss, divided by number of pairs via mean().
    withdrew 已经从 eliminated 里剥离，因此不会参与 loss/metrics。
    """
    elim = week_data.get("eliminated", [])
    if not elim:
        return torch.tensor(0.0, device=p_fan.device), 0

    teams_global = week_data["teams"]
    all_indices = torch.arange(len(teams_global), device=p_fan.device)

    loser_mask = torch.tensor([tid in elim for tid in teams_global], device=p_fan.device)
    winner_indices = all_indices[~loser_mask]
    loser_indices = all_indices[loser_mask]

    if winner_indices.numel() == 0 or loser_indices.numel() == 0:
        return torch.tensor(0.0, device=p_fan.device), 0

    s_diff = s_total[winner_indices].unsqueeze(1) - s_total[loser_indices].unsqueeze(0)
    xi_m = float(config.get("loss", {}).get("xi_margin", 0.05))
    l_base = F.relu(xi_m - s_diff).mean()

    l_twist = torch.tensor(0.0, device=p_fan.device)
    loss_cfg = config.get("loss", {})
    twist_mode = str(loss_cfg.get("twist_mode", "hinge")).lower()

    season = int(week_data.get("season", 0))
    if season >= 28 and twist_mode == "hinge":
        if loser_indices.numel() == 1 and all_indices.numel() > 2 and int(week_data["week"]) < int(week_data["max_week"]):
            e_idx = int(loser_indices[0].item())
            s_proxy_idx = int(winner_indices[torch.argmin(s_total[winner_indices])].item())

            xi_t = float(loss_cfg.get("xi_twist", 0.05))
            xi_tb = float(loss_cfg.get("xi_tb", 0.05))
            lamA = float(loss_cfg.get("lambdaA", 0.2))
            lamB = float(loss_cfg.get("lambdaB", 0.2))

            for k in all_indices:
                kk = int(k.item())
                if kk != e_idx and kk != s_proxy_idx:
                    l_twist = l_twist + F.relu(xi_t - (s_total[kk] - s_total[e_idx])) \
                                      + F.relu(xi_t - (s_total[kk] - s_total[s_proxy_idx]))

            l_twist = l_twist / float(all_indices.numel() - 2)

            j_total = week_data["j_total"].to(p_fan.device)
            l_b = F.relu(xi_tb - (j_total[s_proxy_idx] - j_total[e_idx]))
            l_twist = lamA * l_twist + lamB * l_b

    return l_base + l_twist, 1
