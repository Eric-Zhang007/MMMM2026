import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict


class DWTSModel(nn.Module):
    """
    IdentityScore_{i,t} = theta_c + theta_rw(c,t) + u_p + u_rw(p,t) + phi^T x_i
    where rw terms are time-drift embeddings; random-walk prior is enforced in losses.py.

    Optional MC dropout for inference:
      forward(..., mc_dropout=True, dropout_p=...) applies dropout to eta even in eval mode.
    """
    def __init__(self, num_celebs: int, num_partners: int, feat_dim: int, config: Dict):
        super().__init__()
        self.config = config

        self.theta = nn.Embedding(num_celebs, 1)
        self.u = nn.Embedding(num_partners, 1)
        self.phi = nn.Linear(feat_dim, 1, bias=False)

        beta_center = float(config["model"].get("beta_center", 1.0))
        self.beta = nn.Parameter(torch.tensor([beta_center, beta_center], dtype=torch.float32))

        self.max_week_cap = int(config["model"].get("max_week_cap", 12))
        self.use_time_drift = bool(config["model"].get("use_time_drift", True))

        if self.use_time_drift:
            self.theta_rw = nn.Embedding(num_celebs * self.max_week_cap, 1)
            self.u_rw = nn.Embedding(num_partners * self.max_week_cap, 1)
            nn.init.zeros_(self.theta_rw.weight)
            nn.init.zeros_(self.u_rw.weight)
        else:
            self.theta_rw = None
            self.u_rw = None

        nn.init.normal_(self.theta.weight, std=0.01)
        nn.init.normal_(self.u.weight, std=0.01)
        nn.init.normal_(self.phi.weight, std=0.01)

    def _week_offset_idx(self, base_idx: torch.Tensor, week: int) -> torch.Tensor:
        w = int(week) - 1
        w = max(0, min(self.max_week_cap - 1, w))
        return base_idx * self.max_week_cap + w

    def forward(self, week_data: Dict, all_feats: torch.Tensor, *, mc_dropout: bool = False, dropout_p: float = 0.0):
        device = all_feats.device
        eps = float(self.config.get("features", {}).get("eps", 1e-6))

        c_idx = torch.tensor(week_data["celebrities"], device=device)
        p_idx = torch.tensor(week_data["partners"], device=device)
        t_idx = torch.tensor(week_data["teams"], device=device)

        theta_base = self.theta(c_idx).squeeze(-1)
        u_base = self.u(p_idx).squeeze(-1)
        phi_x = self.phi(all_feats[t_idx]).squeeze(-1)

        if self.use_time_drift and (self.theta_rw is not None) and (self.u_rw is not None):
            w = int(week_data["week"])
            theta_drift = self.theta_rw(self._week_offset_idx(c_idx, w)).squeeze(-1)
            u_drift = self.u_rw(self._week_offset_idx(p_idx, w)).squeeze(-1)
        else:
            theta_drift = 0.0
            u_drift = 0.0

        id_scores = theta_base + theta_drift + u_base + u_drift + phi_x

        zj = week_data["zj"].to(device)
        dzj = week_data["dzj"].to(device)
        perf_in = self.beta[0] * zj + self.beta[1] * dzj

        sigma_fan2 = torch.var(id_scores, unbiased=False)
        sigma_judge2 = torch.var(week_data["j_pct"].to(device), unbiased=False)

        k = float(self.config["model"].get("k_variance_ratio", 1.0))
        alpha = sigma_judge2 / (sigma_judge2 + k * sigma_fan2 + eps)

        lambda_perf = float(self.config["model"].get("lambda_perf", 1.0))
        eta = (1.0 - alpha) * id_scores + alpha * lambda_perf * perf_in

        p = float(dropout_p or 0.0)
        if p > 0.0:
            eta = F.dropout(eta, p=p, training=(self.training or mc_dropout))

        p_fan = F.softmax(eta, dim=0)

        season = int(week_data["season"])
        if 3 <= season <= 27:
            s_total = week_data["j_pct"].to(device) + p_fan
        else:
            rj = week_data["rj"].to(device)
            tau = float(self.config["model"].get("tau_rank", 0.7))
            diff = (eta.unsqueeze(0) - eta.unsqueeze(1)) / tau
            soft_rank = 1.0 + torch.sum(torch.sigmoid(diff), dim=1) - 0.5
            s_total = -(rj + soft_rank)

        return p_fan, s_total, alpha, id_scores
