import argparse
import os
import torch

from src.data import DWTSDataset
from src.features import build_features
from src.model import DWTSModel
from src.train import export_results
from src.utils import load_config, setup_logging, ensure_dir


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, default=None)
    parser.add_argument("--run_dir", type=str, required=True)
    parser.add_argument("--mc_passes", type=int, default=200)
    parser.add_argument("--mc_dropout_p", type=float, default=0.2)
    parser.add_argument("--save_mc_samples", action="store_true")
    parser.add_argument("--device", type=str, default="auto")
    args = parser.parse_args()

    setup_logging()

    cfg = load_config(args.config, overrides=None)
    cfg.setdefault("inference", {})
    cfg["inference"]["mc_passes"] = int(args.mc_passes)
    cfg["inference"]["mc_dropout_p"] = float(args.mc_dropout_p)
    cfg["inference"]["save_mc_samples"] = bool(args.save_mc_samples)

    device = torch.device("cuda" if (args.device == "auto" and torch.cuda.is_available()) else args.device)
    if args.device == "auto" and not torch.cuda.is_available():
        device = torch.device("cpu")

    dataset = DWTSDataset(str(cfg["data_path"]), cfg)
    all_feats = build_features(dataset.df, cfg).to(device)

    model = DWTSModel(len(dataset.celebrities), len(dataset.partners), all_feats.shape[1], cfg).to(device)

    ckpt_path = os.path.join(args.run_dir, "model_best.pt")
    if not os.path.exists(ckpt_path):
        ckpt_path = os.path.join(args.run_dir, "model_last.pt")
    if not os.path.exists(ckpt_path):
        raise FileNotFoundError(f"Checkpoint not found in {args.run_dir}")

    ckpt = torch.load(ckpt_path, map_location=device)
    model.load_state_dict(ckpt["model"])

    out_dir = ensure_dir(args.run_dir)
    export_results(model, dataset, all_feats, out_dir, cfg)


if __name__ == "__main__":
    main()
