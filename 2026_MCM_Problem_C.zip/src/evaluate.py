import math
import torch
from typing import Dict, Optional


def calculate_metrics(week_data: Dict, s_total: torch.Tensor, config: Optional[Dict] = None):
    """
    Kept names:
    - ElimTop1Acc
    - ElimInBottom2Acc
    - MeanMargin

    Added:
    - BottomKAcc: K=|L| (multi-elimination correctness)
    - AvgLogLik / Perplexity: pairwise BT likelihood on winner-loser pairs
    - RuleReproRateWeek: 1 iff all true eliminated are inside bottom-K (K=|L|)
    """
    elim_global = week_data.get("eliminated", [])
    if not elim_global:
        return None

    teams_global = week_data["teams"]
    loser_idx = [i for i, tid in enumerate(teams_global) if tid in elim_global]
    K = len(loser_idx)
    n = int(s_total.numel())
    if K == 0 or n == 0:
        return None

    order = torch.argsort(s_total, descending=False)  # worst -> best

    top1_hit = 1.0 if int(order[0].item()) in loser_idx else 0.0

    b2 = min(2, n)
    bottom2 = set(int(x.item()) for x in order[:b2])
    bottom2_hit = sum(1.0 for x in loser_idx if x in bottom2) / float(K)

    bk = min(K, n)
    bottomk = set(int(x.item()) for x in order[:bk])
    bottomk_hit = sum(1.0 for x in loser_idx if x in bottomk) / float(K)

    rule_repro = 1.0 if all(x in bottomk for x in loser_idx) else 0.0

    safe_idx = [i for i in range(n) if i not in loser_idx]
    mean_margin = 0.0
    if safe_idx:
        winner_min = float(s_total[safe_idx].min().item())
        loser_max = float(s_total[loser_idx].max().item())
        mean_margin = winner_min - loser_max

    tau_ll = 1.0
    if config is not None:
        tau_ll = float(config.get("metrics", {}).get("tau_ll", 1.0))

    avg_loglik = None
    perplexity = None
    if safe_idx:
        s_w = s_total[safe_idx]
        s_l = s_total[loser_idx]
        diff = (s_w.unsqueeze(1) - s_l.unsqueeze(0)) / tau_ll
        logp = torch.log(torch.sigmoid(diff).clamp_min(1e-12))
        avg_loglik = float(logp.mean().item())
        perplexity = float(math.exp(-avg_loglik))

    return {
        "ElimTop1Acc": top1_hit,
        "ElimInBottom2Acc": bottom2_hit,
        "MeanMargin": mean_margin,
        "BottomKAcc": bottomk_hit,
        "RuleReproRateWeek": rule_repro,
        "AvgLogLik": avg_loglik,
        "Perplexity": perplexity,
    }
