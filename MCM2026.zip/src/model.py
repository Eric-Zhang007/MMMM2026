from typing import Dict, Any, Tuple
import torch
import torch.nn as nn
import torch.nn.functional as F


def _inference_dropout(x: torch.Tensor, p: float, enabled: bool) -> torch.Tensor:
    """
    只在推断采样时启用的 dropout（不依赖 model.train()），避免影响训练指标。
    """
    if (not enabled) or p <= 0.0:
        return x
    keep = 1.0 - p
    mask = (torch.rand_like(x) < keep).float() / keep
    return x * mask


class DWTSModel(nn.Module):
    def __init__(self, num_celebs: int, num_partners: int, feat_dim: int, num_obs: int, config: Dict[str, Any]):
        super().__init__()
        self.config = config

        self.theta = nn.Embedding(num_celebs, 1)
        self.u = nn.Embedding(num_partners, 1)
        self.phi = nn.Linear(feat_dim, 1, bias=False)

        # beta_1, beta_2
        beta_center = float(config["model"]["beta_center"])
        self.beta = nn.Parameter(torch.tensor([beta_center, beta_center], dtype=torch.float32))

        # F1 dynamic state r_{i,t} for each active (team,week) observation
        self.r = nn.Embedding(num_obs, 1)

        nn.init.normal_(self.theta.weight, std=0.01)
        nn.init.normal_(self.u.weight, std=0.01)
        nn.init.normal_(self.phi.weight, std=0.01)
        nn.init.normal_(self.r.weight, std=0.01)

    def forward(self, week_data: Dict[str, Any], all_feats: torch.Tensor,
                mc_sample: bool = False) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, Dict[str, torch.Tensor]]:
        device = all_feats.device
        eps = float(self.config["features"]["eps"])

        c_idx = torch.tensor(week_data["celebrities"], device=device, dtype=torch.long)
        p_idx = torch.tensor(week_data["partners"], device=device, dtype=torch.long)
        t_idx = torch.tensor(week_data["teams"], device=device, dtype=torch.long)

        obs_ids = torch.tensor(week_data["obs_ids"], device=device, dtype=torch.long)

        # IdentityScore
        id_scores = self.theta(c_idx).squeeze(-1) + self.u(p_idx).squeeze(-1) + self.phi(all_feats[t_idx]).squeeze(-1)

        # PerfInput
        zj = week_data["zj"].to(device)
        dzj = week_data["dzj"].to(device)
        perf_in = self.beta[0] * zj + self.beta[1] * dzj

        # dynamic alpha
        sigma_fan2 = torch.var(id_scores, unbiased=False)
        sigma_judge2 = torch.var(week_data["j_pct"].to(device), unbiased=False)
        k = float(self.config["model"]["k_variance_ratio"])
        alpha = sigma_judge2 / (sigma_judge2 + k * sigma_fan2 + eps)

        # latent eta + F1 dynamic r
        lam_perf = float(self.config["model"]["lambda_perf"])
        eta = (1.0 - alpha) * id_scores + alpha * lam_perf * perf_in + self.r(obs_ids).squeeze(-1)

        # MC sampling dropout (inference only)
        if self.config.get("uncertainty", {}).get("mc_dropout", {}).get("enabled", False):
            p_drop = float(self.config["uncertainty"]["mc_dropout"]["p"])
            eta = _inference_dropout(eta, p_drop, enabled=mc_sample)

        # fan share
        p_fan = F.softmax(eta, dim=0)

        # total score / risk proxy by season rules
        season = int(week_data["season"])
        if 3 <= season <= 27:
            s_total = week_data["j_pct"].to(device) + p_fan
        else:
            # soft-rank for fan part
            tau = float(self.config["model"]["tau_rank"])
            # diff[k,i] = eta_k - eta_i
            diff = (eta.unsqueeze(0) - eta.unsqueeze(1)) / tau
            soft_rank = 1.0 + torch.sum(torch.sigmoid(diff), dim=0) - 0.5
            s_total = -(week_data["rj"].to(device) + soft_rank)

        aux = {
            "eta": eta.detach(),
            "id_scores": id_scores.detach(),
            "perf_in": perf_in.detach(),
        }
        return p_fan, s_total, alpha, aux
