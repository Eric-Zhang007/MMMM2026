from typing import Dict, Any, Optional
import math
import torch
import torch.nn.functional as F


def calculate_metrics(week_data: Dict[str, Any],
                      s_total: torch.Tensor,
                      config: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, float]]:
    """
    保留指标名字不动：
    - ElimTop1Acc
    - ElimInBottom2Acc
    - MeanMargin

    新增（不要求终端都打印，但会返回供 train.py 记录）：
    - AvgLogLik
    - Perplexity
    """
    elim_ids = set(week_data.get("eliminated", []))
    if len(elim_ids) == 0:
        return None

    device = s_total.device
    teams = week_data["teams"]
    n = len(teams)

    loser_local = [i for i, tid in enumerate(teams) if tid in elim_ids]
    if len(loser_local) == 0:
        return None

    order = torch.argsort(s_total, descending=False)  # 最低 = 最危险

    # Top1：最危险者是否属于真实淘汰集合
    top1_hit = 1.0 if int(order[0].item()) in loser_local else 0.0

    # Top2：bottom2 中属于真实淘汰的比例 / 2（适配多人淘汰周）
    bottom2 = set(int(x.item()) for x in order[: min(2, n)])
    elim_in_bottom2 = sum(1 for i in bottom2 if i in set(loser_local))
    elim_in_bottom2_acc = float(elim_in_bottom2) / float(min(2, n))

    # MeanMargin：最差幸存者 - 最好淘汰者
    winners = [i for i in range(n) if i not in loser_local]
    if len(winners) == 0:
        mean_margin = 0.0
    else:
        worst_winner = float(s_total[winners].min().item())
        best_loser = float(s_total[loser_local].max().item())
        mean_margin = worst_winner - best_loser

    # AvgLogLik surrogate (pairwise logistic on winner>loser)
    tau = 0.1
    if config is not None:
        tau = float(config.get("metrics", {}).get("pairwise_tau", 0.1))
    tau = max(tau, 1e-6)

    # winner vs loser pairs
    if len(winners) == 0:
        avg_loglik = 0.0
        ppl = float("inf")
    else:
        Sw = s_total[winners].unsqueeze(1)
        Sl = s_total[loser_local].unsqueeze(0)
        # p = sigmoid((Sw - Sl)/tau)
        p = torch.sigmoid((Sw - Sl) / tau)
        # loglik mean
        avg_loglik_t = torch.log(p.clamp_min(1e-12)).mean()
        avg_loglik = float(avg_loglik_t.item())
        ppl = float(math.exp(-avg_loglik)) if avg_loglik > -50 else float("inf")

    return {
        "ElimTop1Acc": top1_hit,
        "ElimInBottom2Acc": elim_in_bottom2_acc,
        "MeanMargin": float(mean_margin),

        "AvgLogLik": float(avg_loglik),
        "Perplexity": float(ppl),
    }
