from typing import Dict, Any, Tuple
import torch
import torch.nn.functional as F


def get_prior_loss(model, config: Dict[str, Any], week_data: Dict[str, Any] = None) -> torch.Tensor:
    """
    改动点：
    - theta/u 分开 L2
    - phi 支持 elasticnet: lambda_phi_l1 * ||w||_1 + lambda_phi_l2 * ||w||_2^2
    - beta 以 (beta - beta_center)^2
    - F1: random-walk penalty on dynamic r using week_data['obs_ids'] & ['prev_obs_ids']
    """
    device = next(model.parameters()).device

    lam_theta = float(config["model"]["lambda_theta"])
    lam_u = float(config["model"]["lambda_u"])
    l_theta = lam_theta * (model.theta.weight.pow(2).mean())
    l_u = lam_u * (model.u.weight.pow(2).mean())

    # phi regularization
    phi_reg = str(config["model"]["phi_reg"]).lower()
    w = model.phi.weight
    lam_l1 = float(config["model"].get("lambda_phi_l1", 0.0))
    lam_l2 = float(config["model"].get("lambda_phi_l2", 0.0))

    if phi_reg == "l1":
        l_phi = lam_l1 * torch.norm(w, 1)
    elif phi_reg == "l2":
        l_phi = lam_l2 * torch.norm(w, 2).pow(2)
    elif phi_reg == "elasticnet":
        l_phi = lam_l1 * torch.norm(w, 1) + lam_l2 * torch.norm(w, 2).pow(2)
    else:
        l_phi = torch.tensor(0.0, device=device)

    # beta prior
    beta_center = float(config["model"]["beta_center"])
    lam_beta = float(config["model"]["lambda_beta"])
    l_beta = lam_beta * torch.sum((model.beta - beta_center) ** 2)

    # random-walk prior for r_{i,t}
    lam_rw = float(config["model"].get("lambda_rw", 0.0))
    l_rw = torch.tensor(0.0, device=device)
    if lam_rw > 0.0 and week_data is not None:
        obs_ids = torch.tensor(week_data["obs_ids"], device=device, dtype=torch.long)
        prev_ids = torch.tensor(week_data["prev_obs_ids"], device=device, dtype=torch.long)
        mask = prev_ids >= 0
        if bool(mask.any()):
            r_cur = model.r(obs_ids[mask]).squeeze(-1)
            r_prev = model.r(prev_ids[mask]).squeeze(-1)
            l_rw = lam_rw * (r_cur - r_prev).pow(2).mean()

    return l_theta + l_u + l_phi + l_beta + l_rw


def compute_loss(week_data: Dict[str, Any],
                 s_total: torch.Tensor,
                 config: Dict[str, Any]) -> Tuple[torch.Tensor, int]:
    """
    改动点：
    - 只对真实淘汰者 eliminated 做监督（withdrew 不纳入）
    - pairwise hinge 用 mean（自动除 pairs 数量）
    - twist loss 仅在 season>=28 且本周真实淘汰人数==1 时启用（尽量不误触发多淘汰周）
    """
    device = s_total.device
    elim_ids = set(week_data.get("eliminated", []))
    if len(elim_ids) == 0:
        return torch.tensor(0.0, device=device), 0

    teams = week_data["teams"]
    n = len(teams)
    all_idx = torch.arange(n, device=device)

    loser_mask = torch.tensor([tid in elim_ids for tid in teams], device=device)
    loser_idx = all_idx[loser_mask]
    winner_idx = all_idx[~loser_mask]

    if loser_idx.numel() == 0 or winner_idx.numel() == 0:
        return torch.tensor(0.0, device=device), 0

    xi = float(config["loss"]["xi_margin"])
    # pairwise hinge mean
    s_diff = s_total[winner_idx].unsqueeze(1) - s_total[loser_idx].unsqueeze(0)
    l_base = F.relu(xi - s_diff).mean()

    # Twist loss (保持你们原思路，尽量最小改动)
    l_twist = torch.tensor(0.0, device=device)
    season = int(week_data["season"])
    if (season >= 28 and
        loser_idx.numel() == 1 and
        n > 2 and
        int(week_data["week"]) < int(week_data["max_week"])):

        e_idx = int(loser_idx[0].item())
        # s_proxy：幸存者中最危险的那个
        s_proxy_local = winner_idx[torch.argmin(s_total[winner_idx])].item()
        s_proxy_idx = int(s_proxy_local)

        xi_t = float(config["loss"]["xi_twist"])

        # L_A：除 {e, s_proxy} 外，其他人都要更安全
        # (保持简单循环，避免大改；n 很小，速度问题不大)
        terms = []
        for k in range(n):
            if k == e_idx or k == s_proxy_idx:
                continue
            terms.append(F.relu(xi_t - (s_total[k] - s_total[e_idx])))
            terms.append(F.relu(xi_t - (s_total[k] - s_total[s_proxy_idx])))
        if len(terms) > 0:
            l_a = torch.stack(terms).mean()
        else:
            l_a = torch.tensor(0.0, device=device)

        # L_B：评委在 bottom-two 的“救赎选择”代理
        xi_tb = float(config["loss"]["xi_tb"])
        j_total = week_data["j_total"].to(device)
        l_b = F.relu(xi_tb - (j_total[s_proxy_idx] - j_total[e_idx]))

        lambdaA = float(config["loss"]["lambdaA"])
        lambdaB = float(config["loss"]["lambdaB"])
        l_twist = lambdaA * l_a + lambdaB * l_b

    return l_base + l_twist, 1
