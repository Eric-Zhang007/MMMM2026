from typing import Dict, List, Any
import numpy as np
import pandas as pd
import torch


class DWTSDataset:
    """
    关键改动：
    1) 读取 results 列，若包含 Withdrew，则把退出标注为 withdrew（不参与淘汰监督）
    2) eliminated 只包含真实淘汰者；新增 withdrew / exited 字段
    3) 为 F1 动态项 r_{i,t} 分配 obs_id，并提供 prev_obs_id 用于随机游走正则
    """

    def __init__(self, csv_path: str, config: Dict[str, Any]):
        self.df = pd.read_csv(csv_path)
        self.config = config
        self.eps = float(config["features"]["eps"])

        self.results_col = config.get("data", {}).get("results_col", "results")
        self.withdrew_token = str(config.get("data", {}).get("withdrew_token", "Withdrew"))
        self.max_weeks_scan = int(config.get("data", {}).get("max_weeks_scan", 11))

        self.prepare_data()

    def _safe_float_scores(self, sdf: pd.DataFrame, cols: List[str]) -> pd.Series:
        # 把 N/A 等转成 NaN，再转 float
        tmp = sdf[cols].replace("N/A", np.nan)
        tmp = tmp.apply(pd.to_numeric, errors="coerce")
        return tmp.sum(axis=1, skipna=True)

    def prepare_data(self) -> None:
        # team_id
        self.df["team_id"] = self.df["celebrity_name"].astype(str) + "__" + self.df["ballroom_partner"].astype(str)

        # maps
        self.teams = self.df["team_id"].unique().tolist()
        self.partners = self.df["ballroom_partner"].unique().tolist()
        self.celebrities = self.df["celebrity_name"].unique().tolist()

        self.team_to_idx = {t: i for i, t in enumerate(self.teams)}
        self.p_to_idx = {p: i for i, p in enumerate(self.partners)}
        self.c_to_idx = {c: i for i, c in enumerate(self.celebrities)}

        # results text per team (row)
        if self.results_col in self.df.columns:
            self.df[self.results_col] = self.df[self.results_col].fillna("").astype(str)
        else:
            # 没有 results 列则全为空
            self.df[self.results_col] = ""

        self.panel: List[Dict[str, Any]] = []

        # obs_id for (team, season, week) active observations
        self.obs_counter = 0
        # 记录每个 season 内每支队伍上一周的 obs_id，便于 RW prior
        # (season, team_id_str) -> obs_id
        prev_obs: Dict[tuple, int] = {}

        seasons = sorted(self.df["season"].unique())
        for s in seasons:
            sdf = self.df[self.df["season"] == s].copy()

            # 预先计算每周总评委分
            week_scores: Dict[int, pd.Series] = {}
            max_w = 0
            for w in range(1, self.max_weeks_scan + 1):
                cols = [f"week{w}_judge{j}_score" for j in range(1, 5)]
                if not all(c in sdf.columns for c in cols):
                    continue
                scores = self._safe_float_scores(sdf, cols)
                if float(scores.sum()) > 0:
                    week_scores[w] = scores
                    max_w = w

            # zJ 的上一周值（只在同一 season 内）
            prev_zj: Dict[str, float] = {}
            prev_active: Dict[str, bool] = {}

            for w in range(1, max_w + 1):
                if w not in week_scores:
                    continue

                scores = week_scores[w]
                active_mask = scores > 0
                if not bool(active_mask.any()):
                    continue

                a_sdf = sdf[active_mask].copy()
                a_scores = scores[active_mask].to_numpy(dtype=float)

                # judge percent (当周 active 的比例)
                j_pct = a_scores / (float(a_scores.sum()) + self.eps)

                # z-score of judge totals (当周 active 内标准化)
                mean_s = float(np.mean(a_scores))
                std_s = float(np.std(a_scores))
                z_j = (a_scores - mean_s) / (std_s + self.eps)

                # rank by judge totals (1 is best)
                r_j = pd.Series(a_scores).rank(ascending=False, method="min").to_numpy(dtype=float)

                # dzJ：仅当连续两周 active 才计算差分，否则 0
                dzj = np.zeros_like(z_j, dtype=float)
                for i, tid in enumerate(a_sdf["team_id"].tolist()):
                    was_active = prev_active.get(tid, False)
                    if was_active and (tid in prev_zj):
                        dzj[i] = float(z_j[i] - prev_zj[tid])
                    else:
                        dzj[i] = 0.0
                    prev_zj[tid] = float(z_j[i])
                    prev_active[tid] = True

                # 本周结束后离场的人：看下一周是否还 active
                eliminated_ids: List[int] = []
                withdrew_ids: List[int] = []
                exited_ids: List[int] = []

                if w < max_w:
                    next_scores = week_scores.get(w + 1, pd.Series(0.0, index=sdf.index))
                    # 同一个 sdf 的 index 对齐是关键，所以直接用 a_sdf 的 idx
                    for idx, row in a_sdf.iterrows():
                        tid = str(row["team_id"])
                        team_idx = self.team_to_idx[tid]
                        if float(next_scores.loc[idx]) <= 0.0:
                            exited_ids.append(team_idx)
                            # 用 results 判别是否 withdrew
                            res_text = str(row.get(self.results_col, ""))
                            if self.withdrew_token.lower() in res_text.lower():
                                withdrew_ids.append(team_idx)
                            else:
                                eliminated_ids.append(team_idx)

                # obs_ids / prev_obs_ids（F1）
                obs_ids: List[int] = []
                prev_obs_ids: List[int] = []
                teams_list = a_sdf["team_id"].tolist()
                for tid in teams_list:
                    key = (int(s), str(tid))
                    prev_id = prev_obs.get(key, -1)
                    cur_id = self.obs_counter
                    self.obs_counter += 1

                    prev_obs[key] = cur_id
                    obs_ids.append(cur_id)
                    prev_obs_ids.append(prev_id)

                week_data = {
                    "season": int(s),
                    "week": int(w),
                    "max_week": int(max_w),

                    "teams": [self.team_to_idx[str(tid)] for tid in teams_list],
                    "partners": [self.p_to_idx[str(p)] for p in a_sdf["ballroom_partner"].tolist()],
                    "celebrities": [self.c_to_idx[str(c)] for c in a_sdf["celebrity_name"].tolist()],

                    "j_pct": torch.tensor(j_pct, dtype=torch.float32),
                    "zj": torch.tensor(z_j, dtype=torch.float32),
                    "dzj": torch.tensor(dzj, dtype=torch.float32),
                    "rj": torch.tensor(r_j, dtype=torch.float32),
                    "j_total": torch.tensor(a_scores, dtype=torch.float32),

                    # 关键：eliminated 不再包含 withdrew
                    "eliminated": eliminated_ids,
                    "withdrew": withdrew_ids,
                    "exited": exited_ids,

                    # F1
                    "obs_ids": obs_ids,
                    "prev_obs_ids": prev_obs_ids,
                }
                self.panel.append(week_data)

            # season 结束：把该 season 内不再出现的队伍 prev_active 维持无所谓
            # prev_obs 也用 (season, team) 键，不会跨 season 污染

        self.num_obs = int(self.obs_counter)

    def __len__(self) -> int:
        return len(self.panel)
