import os
import json
import math
from typing import Dict, Any, Optional, List

import numpy as np
import pandas as pd
import torch
from torch.utils.tensorboard import SummaryWriter

from src.utils import load_config, save_resolved_config, setup_logger, get_device, write_formulas, set_seed
from src.data import DWTSDataset
from src.features import FeatureBuilder, build_all_features
from src.model import DWTSModel
from src.losses import compute_loss, get_prior_loss
from src.evaluate import calculate_metrics


def _make_run_dir(cfg: Dict[str, Any]) -> str:
    out_root = str(cfg["output_root"])
    run_name = str(cfg["run_name"])
    run_dir = os.path.join(out_root, run_name)
    os.makedirs(run_dir, exist_ok=True)
    os.makedirs(os.path.join(run_dir, "tb"), exist_ok=True)
    return run_dir


def _build_optimizer(model: torch.nn.Module, cfg: Dict[str, Any]) -> torch.optim.Optimizer:
    """
    AdamW param_groups:
    - weight_decay ONLY on phi
    - theta/u/beta/r no weight_decay
    """
    lr = float(cfg["training"]["lr"])
    wd = float(cfg["training"].get("weight_decay", 0.0))

    phi_params = list(model.phi.parameters())
    # 其他参数
    other_params = []
    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        if name.startswith("phi."):
            continue
        other_params.append(p)

    param_groups = [
        {"params": other_params, "weight_decay": 0.0},
        {"params": phi_params, "weight_decay": wd},
    ]
    return torch.optim.AdamW(param_groups, lr=lr)


def _build_scheduler(optimizer: torch.optim.Optimizer, cfg: Dict[str, Any]):
    sch = cfg.get("training", {}).get("scheduler", {})
    if str(sch.get("type", "none")).lower() == "plateau":
        factor = float(sch.get("plateau_factor", 0.5))
        patience = int(sch.get("plateau_patience", 5))
        min_lr = float(sch.get("min_lr", 1e-6))
        return torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, mode="max", factor=factor, patience=patience, min_lr=min_lr
        )
    return None


def train(config_path: Optional[str] = None,
          overrides: Optional[Dict[str, Any]] = None,
          panel_indices: Optional[List[int]] = None) -> float:
    cfg = load_config("configs/default.yaml", config_path, overrides)
    run_dir = _make_run_dir(cfg)
    setup_logger(run_dir)

    save_resolved_config(cfg, os.path.join(run_dir, "config_resolved.yaml"))
    write_formulas(os.path.join(run_dir, "formulas.txt"), cfg)

    # seed（可按需加到 config 里；这里给个默认）
    seed = int(cfg.get("training", {}).get("seed", 42))
    set_seed(seed)

    device = get_device(str(cfg["device"]))

    dataset = DWTSDataset(str(cfg["data_path"]), cfg)
    fb = FeatureBuilder(dataset.df, cfg)
    all_feats = build_all_features(dataset, fb).to(device)

    model = DWTSModel(
        num_celebs=len(dataset.celebrities),
        num_partners=len(dataset.partners),
        feat_dim=fb.dim,
        num_obs=dataset.num_obs,
        config=cfg,
    ).to(device)

    optimizer = _build_optimizer(model, cfg)
    scheduler = _build_scheduler(optimizer, cfg)

    writer = SummaryWriter(os.path.join(run_dir, "tb"))

    # resume
    start_epoch = 0
    best_top1 = -1.0
    resume_from = str(cfg.get("training", {}).get("resume_from", "none")).lower()
    if resume_from in ["last", "best"]:
        ckpt_path = os.path.join(run_dir, f"model_{resume_from}.pt")
        if os.path.exists(ckpt_path):
            ckpt = torch.load(ckpt_path, map_location="cpu")
            model.load_state_dict(ckpt["model"])
            optimizer.load_state_dict(ckpt["optimizer"])
            start_epoch = int(ckpt.get("epoch", 0)) + 1
            best_top1 = float(ckpt.get("best_top1", best_top1))

    epochs = int(cfg["training"]["epochs"])
    patience = int(cfg["training"]["patience"])
    grad_clip = float(cfg["training"].get("grad_clip_norm", 0.0))
    accum_steps = int(cfg["training"].get("grad_accum_steps", 1))
    accum_steps = max(accum_steps, 1)

    patience_counter = 0

    # choose panels
    panels = dataset.panel
    if panel_indices is not None:
        panels = [dataset.panel[i] for i in panel_indices]

    for epoch in range(start_epoch, epochs):
        model.train()
        optimizer.zero_grad(set_to_none=True)

        total_loss = 0.0
        metrics_list = []

        step_count = 0

        for week_data in panels:
            # forward (training is deterministic; mc_sample=False)
            p_fan, s_total, alpha, aux = model(week_data, all_feats, mc_sample=False)

            # base loss (only true eliminated, no withdrew)
            l_base, used = compute_loss(week_data, s_total, cfg)
            if used == 0:
                continue

            # priors include RW (need week_data)
            l_prior = get_prior_loss(model, cfg, week_data=week_data)

            loss = l_base + l_prior
            loss.backward()

            step_count += 1
            if step_count % accum_steps == 0:
                if grad_clip > 0.0:
                    torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=grad_clip)
                optimizer.step()
                optimizer.zero_grad(set_to_none=True)

            total_loss += float(loss.item())

            m = calculate_metrics(week_data, s_total.detach(), cfg)
            if m is not None:
                metrics_list.append(m)

        # flush remaining grads
        if step_count % accum_steps != 0:
            if grad_clip > 0.0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=grad_clip)
            optimizer.step()
            optimizer.zero_grad(set_to_none=True)

        # epoch metrics
        if len(metrics_list) > 0:
            top1 = float(np.mean([x["ElimTop1Acc"] for x in metrics_list]))
            top2 = float(np.mean([x["ElimInBottom2Acc"] for x in metrics_list]))
            mean_margin = float(np.mean([x["MeanMargin"] for x in metrics_list]))
            avg_loglik = float(np.mean([x["AvgLogLik"] for x in metrics_list]))
        else:
            top1, top2, mean_margin, avg_loglik = 0.0, 0.0, 0.0, 0.0

        # tensorboard
        writer.add_scalar("Loss/train", total_loss, epoch)
        writer.add_scalar("ElimTop1Acc/train", top1, epoch)
        writer.add_scalar("ElimInBottom2Acc/train", top2, epoch)
        writer.add_scalar("MeanMargin/train", mean_margin, epoch)
        writer.add_scalar("AvgLogLik/train", avg_loglik, epoch)
        writer.add_scalar("LR/lr", float(optimizer.param_groups[0]["lr"]), epoch)

        # scheduler by monitor (Top1)
        if scheduler is not None:
            scheduler.step(top1)

        # checkpoint
        ckpt = {
            "epoch": epoch,
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "best_top1": best_top1,
        }
        torch.save(ckpt, os.path.join(run_dir, "model_last.pt"))

        improved = top1 > best_top1
        if improved:
            best_top1 = top1
            ckpt["best_top1"] = best_top1
            torch.save(ckpt, os.path.join(run_dir, "model_best.pt"))
            patience_counter = 0
        else:
            patience_counter += 1

        # terminal output: only three + AvgLogLik + pat
        print(
            f"Epoch {epoch:04d} | Loss {total_loss:.6f} | "
            f"ElimTop1Acc {top1:.4f} | ElimInBottom2Acc {top2:.4f} | "
            f"MeanMargin {mean_margin:.4f} | AvgLogLik {avg_loglik:.4f} | "
            f"pat={patience_counter}/{patience}"
        )

        if patience_counter >= patience:
            break

    # export
    export_results(model, dataset, all_feats, fb, cfg, run_dir)
    return best_top1


def export_results(model: DWTSModel,
                   dataset: DWTSDataset,
                   all_feats: torch.Tensor,
                   fb: FeatureBuilder,
                   cfg: Dict[str, Any],
                   run_dir: str) -> None:
    """
    你要求的导出：
    - 每队每周：season, week, team_id, P_fan, S_total, alpha
    - + p_elim（softmax on risk）
    - + true_eliminated / true_withdrew / pred_eliminated / hit（用 'Y'/空）
    - + D & Z（P_fan - J_pct 的 zscore），并标 outlier 90/95
    - + margin（best loser vs worst winner）
    - + MC dropout samples: long-format 供箱线/小提琴（可关）
    - + team params: theta, u, x_i, phi
    """
    device = all_feats.device
    model.eval()

    z90 = float(cfg.get("metrics", {}).get("outlier_z_90", 1.645))
    z95 = float(cfg.get("metrics", {}).get("outlier_z_95", 1.96))
    eps = float(cfg["features"]["eps"])

    rows = []
    sample_rows = []  # for violin/box

    mc_cfg = cfg.get("uncertainty", {}).get("mc_dropout", {})
    mc_enabled = bool(mc_cfg.get("enabled", False))
    mc_n = int(mc_cfg.get("n_samples", 200))

    with torch.no_grad():
        for week_data in dataset.panel:
            # deterministic forward
            p_fan, s_total, alpha, aux = model(week_data, all_feats, mc_sample=False)

            teams_idx = week_data["teams"]
            team_ids = [dataset.teams[i] for i in teams_idx]

            j_pct = week_data["j_pct"].to(device)
            # D and Z within week
            D = (p_fan - j_pct)
            muD = float(D.mean().item())
            sdD = float(D.std(unbiased=False).item())
            Z = (D - muD) / (sdD + eps)

            # true labels
            true_elim_set = set(week_data.get("eliminated", []))
            true_wd_set = set(week_data.get("withdrew", []))

            # predicted elimination set size = number of true eliminated this week
            m = len(true_elim_set)
            pred_set = set()
            if m > 0:
                order = torch.argsort(s_total, descending=False)
                pred_local = set(int(x.item()) for x in order[:m])
                pred_set = pred_local

            # p_elim as softmax on risk = -S_total
            risk = (-s_total)
            p_elim = torch.softmax(risk, dim=0)

            # margin: worst winner - best loser (true eliminated only)
            loser_local = [i for i, tid in enumerate(teams_idx) if tid in true_elim_set]
            winner_local = [i for i, tid in enumerate(teams_idx) if tid not in true_elim_set]
            if len(loser_local) > 0 and len(winner_local) > 0:
                worst_winner = float(s_total[winner_local].min().item())
                best_loser = float(s_total[loser_local].max().item())
                margin = worst_winner - best_loser
            else:
                margin = 0.0

            # per-row export
            for local_i, tid in enumerate(team_ids):
                global_team_idx = teams_idx[local_i]

                true_elim_flag = "Y" if global_team_idx in true_elim_set else ""
                true_wd_flag = "Y" if global_team_idx in true_wd_set else ""

                pred_elim_flag = ""
                hit_flag = ""
                if m > 0:
                    pred_elim_flag = "Y" if local_i in pred_set else ""
                    hit_flag = "Y" if (pred_elim_flag == "Y" and true_elim_flag == "Y") else ""

                z_val = float(Z[local_i].item())
                z90_flag = "Y" if abs(z_val) > z90 else ""
                z95_flag = "Y" if abs(z_val) > z95 else ""

                rows.append({
                    "season": int(week_data["season"]),
                    "week": int(week_data["week"]),
                    "team_id": tid,

                    "P_fan": float(p_fan[local_i].item()),
                    "S_total": float(s_total[local_i].item()),
                    "alpha": float(alpha.item()),

                    "p_elim": float(p_elim[local_i].item()),

                    "true_eliminated": true_elim_flag,
                    "true_withdrew": true_wd_flag,
                    "pred_eliminated": pred_elim_flag,
                    "hit": hit_flag,

                    "D_pf_minus_j": float(D[local_i].item()),
                    "Z_pf_minus_j": z_val,
                    "Z_outlier_90": z90_flag,
                    "Z_outlier_95": z95_flag,

                    "best_loser_worst_winner_margin": float(margin),
                })

            # MC dropout sampling for CI & violin data (optional)
            if mc_enabled and mc_n > 0:
                # collect samples for this week
                pf_samples = []
                for s in range(mc_n):
                    pf_s, st_s, a_s, _ = model(week_data, all_feats, mc_sample=True)
                    pf_samples.append(pf_s.unsqueeze(0))
                    # long-format per sample (用于箱线/小提琴)
                    for local_i, tid in enumerate(team_ids):
                        sample_rows.append({
                            "season": int(week_data["season"]),
                            "week": int(week_data["week"]),
                            "team_id": tid,
                            "sample_id": int(s),
                            "P_fan": float(pf_s[local_i].item()),
                        })
                pf_samples = torch.cat(pf_samples, dim=0)  # [S, n_team]
                lo = torch.quantile(pf_samples, 0.025, dim=0)
                hi = torch.quantile(pf_samples, 0.975, dim=0)

                # 把 CI 回填到 rows（最后 n_team 行就是这一周的）
                n_team = len(team_ids)
                for k in range(n_team):
                    rows[-n_team + k]["P_fan_ci_low_95"] = float(lo[k].item())
                    rows[-n_team + k]["P_fan_ci_high_95"] = float(hi[k].item())

    # main per-week per-team table
    out_csv = os.path.join(run_dir, "pred_fan_shares_enriched.csv")
    pd.DataFrame(rows).to_csv(out_csv, index=False)

    # long-format samples for plots
    if mc_enabled and len(sample_rows) > 0:
        out_samp = os.path.join(run_dir, "pfan_samples_long.csv")
        pd.DataFrame(sample_rows).to_csv(out_samp, index=False)

    # team-season Z summary
    df_rows = pd.DataFrame(rows)
    if len(df_rows) > 0:
        zsum = (df_rows.groupby(["season", "team_id"])["Z_pf_minus_j"]
                .agg(["mean", "std", "max", "min"])
                .reset_index())
        zsum = zsum.rename(columns={"mean": "Z_mean", "std": "Z_std", "max": "Z_max", "min": "Z_min"})
        zsum.to_csv(os.path.join(run_dir, "team_season_Z_summary.csv"), index=False)

    # static params per team: theta, u, x_i, phi
    _export_team_params(model, dataset, all_feats, fb, run_dir)


def _export_team_params(model: DWTSModel,
                        dataset: DWTSDataset,
                        all_feats: torch.Tensor,
                        fb: FeatureBuilder,
                        run_dir: str) -> None:
    """
    对每个 team 保存：
    - theta_i（明星标量）
    - u_partner（舞者标量）
    - x_i（向量）
    - phi（向量）
    以 CSV 输出，其中向量用 JSON 字符串存。
    """
    device = all_feats.device
    model.eval()

    # phi vector
    phi_vec = model.phi.weight.detach().cpu().view(-1).tolist()

    rows = []
    with torch.no_grad():
        for tid in dataset.teams:
            row0 = dataset.df[dataset.df["team_id"] == tid].iloc[0]
            celeb = str(row0["celebrity_name"])
            partner = str(row0["ballroom_partner"])

            c_idx = torch.tensor([dataset.c_to_idx[celeb]], device=device, dtype=torch.long)
            p_idx = torch.tensor([dataset.p_to_idx[partner]], device=device, dtype=torch.long)
            t_idx = torch.tensor([dataset.team_to_idx[tid]], device=device, dtype=torch.long)

            theta = float(model.theta(c_idx).squeeze().item())
            u = float(model.u(p_idx).squeeze().item())
            x_i = all_feats[t_idx].detach().cpu().view(-1).tolist()

            rows.append({
                "team_id": tid,
                "celebrity_name": celeb,
                "ballroom_partner": partner,
                "theta": theta,
                "u_partner": u,
                "x_i": json.dumps(x_i),
                "phi": json.dumps(phi_vec),
            })

    pd.DataFrame(rows).to_csv(os.path.join(run_dir, "team_static_params.csv"), index=False)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, default=None)
    args = parser.parse_args()

    train(config_path=args.config)
